<h1>URL shortener - Chrome extension</h1>

<p>This Chrome extension allow you to create shortened URLs.</p>